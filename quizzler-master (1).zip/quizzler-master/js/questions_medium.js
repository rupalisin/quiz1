// creating an array and passing the number, questions, options, and answers
let questions = [{
    numb: 1,
    question: "Which of the following attributes of text box control allow to limit the maximum character?",
    answer: "maxlength",
    options: [
        "size",
        "len",
        "maxlength",
        "all of these"
    ]
},
{
    numb: 2,
    question: "Which of the following options is correct with regard to HTML?",
    answer: "It is used to structure documents",
    options: [
        "It is a modelling language",
        "It is a DTP language",
        "It is a partial programming language",
        "It is used to structure documents"
    ]
},
{
    numb: 3,
    question: "HTML markup language is a set of Markup ___________.",
    answer: "Tags",
    options: [
        "Tags",
        "Attributes",
        "Groups",
        "Sets"
    ]
},
{
    numb: 4,
    question: "There are ____ different of heading tags in HTML.",
    answer: "6",
    options: [
        "4",
        "5",
        "6",
        "7"
    ]
},
{
    numb: 5,
    question: "Which of the following selector matches a particular element only when it lies inside a particular element?",
    answer: "The Descendant Selector",
    options: [
        "The Type Selector",
        "The Descendant Selector",
        "The Universal Selector",
        "The Class Selector"
    ]
}
];