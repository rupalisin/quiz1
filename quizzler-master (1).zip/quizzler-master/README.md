# quizzler
A quiz app.
This quiz has 3 Levels -  Easy, Medium and Hard.
Each Level has 5 Questions.
Each question should be done in 15 seconds.
One point will be awarded for the correct answer and zero for incorrect.
